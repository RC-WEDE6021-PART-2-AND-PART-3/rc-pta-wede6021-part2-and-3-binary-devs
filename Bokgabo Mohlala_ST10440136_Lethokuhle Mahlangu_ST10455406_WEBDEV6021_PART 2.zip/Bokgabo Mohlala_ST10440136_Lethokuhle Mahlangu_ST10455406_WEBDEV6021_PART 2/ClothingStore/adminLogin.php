<?php
session_start();
require_once 'DBConn.php';

$error = "";
$email = "";

// If admin already logged in, go straight to admin panel
if (isset($_SESSION['adminID'])) {
    header("Location: adminPanel.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email    = $conn->real_escape_string($_POST['email']);
    $password = $_POST['password'];

    $query  = "SELECT * FROM tblAdmin WHERE email = '$email'";
    $result = $conn->query($query);

    if ($result->num_rows == 1) {
        $admin = $result->fetch_assoc();

        if (md5($password) == $admin['password']) {
            $_SESSION['adminID']    = $admin['adminID'];
            $_SESSION['adminFirst'] = $admin['firstName'];
            $_SESSION['adminLast']  = $admin['lastName'];
            $_SESSION['adminEmail'] = $admin['email'];
            header("Location: adminPanel.php");
            exit();
        } else {
            $error = "Incorrect password.";
        }
    } else {
        $error = "No admin account found with that email.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>ClothingStore - Admin Login</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #1a1a2e;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .login-box {
            background: white;
            padding: 40px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.3);
            width: 350px;
        }
        h2 {
            text-align: center;
            color: #1a1a2e;
            margin-bottom: 5px;
        }
        .subtitle {
            text-align: center;
            color: #888;
            margin-bottom: 20px;
            font-size: 14px;
        }
        .error {
            background: #ffe0e0;
            color: #cc0000;
            padding: 10px;
            border-radius: 4px;
            margin-bottom: 15px;
            text-align: center;
        }
        label {
            font-weight: bold;
            color: #333;
        }
        input[type="email"],
        input[type="password"] {
            width: 100%;
            padding: 10px;
            margin: 8px 0 16px 0;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }
        input[type="submit"] {
            width: 100%;
            padding: 10px;
            background: #1a1a2e;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
        }
        input[type="submit"]:hover {
            background: #2a2a4e;
        }
        .links {
            text-align: center;
            margin-top: 15px;
        }
        .links a {
            color: #1a1a2e;
            text-decoration: none;
        }
        .links a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>

<div class="login-box">
    <h2>Admin Login</h2>
    <p class="subtitle">ClothingStore Administrator Portal</p>

    <?php if (!empty($error)): ?>
        <div class="error"><?php echo $error; ?></div>
    <?php endif; ?>

    <form method="POST" action="adminLogin.php">
        <label>Email Address:</label>
        <input type="email" name="email"
               value="<?php echo htmlspecialchars($email); ?>"
               required>

        <label>Password:</label>
        <input type="password" name="password" required>

        <input type="submit" value="Admin Login">
    </form>

    <div class="links">
        <a href="index.php">← Back to User Login</a>
    </div>
</div>

</body>
</html>