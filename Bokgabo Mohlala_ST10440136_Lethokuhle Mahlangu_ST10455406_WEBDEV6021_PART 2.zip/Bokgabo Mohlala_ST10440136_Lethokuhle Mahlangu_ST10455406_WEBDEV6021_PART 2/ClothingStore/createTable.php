<?php
// Include the database connection
require_once 'DBConn.php';

// Disable foreign key checks so we can drop tables freely
$conn->query("SET FOREIGN_KEY_CHECKS=0");

// Drop tblOrder first (has foreign key to tblUser)
$conn->query("DROP TABLE IF EXISTS tblOrder");
echo "tblOrder dropped <br>";

// Now drop tblUser
$dropTable = "DROP TABLE IF EXISTS tblUser";
if ($conn->query($dropTable) === TRUE) {
    echo "tblUser dropped successfully <br>";
} else {
    echo "Error dropping table: " . $conn->error . "<br>";
}

// Re-enable foreign key checks
$conn->query("SET FOREIGN_KEY_CHECKS=1");

// Recreate tblUser
$createTable = "CREATE TABLE tblUser (
    userID INT(11) AUTO_INCREMENT PRIMARY KEY,
    firstName VARCHAR(50) NOT NULL,
    lastName VARCHAR(50) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    isVerified TINYINT(1) DEFAULT 0,
    createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)";

if ($conn->query($createTable) === TRUE) {
    echo "Table created successfully <br>";
} else {
    echo "Error creating table: " . $conn->error . "<br>";
}

// Read userData.txt and load into tblUser
$file = fopen("userData.txt", "r");

if ($file) {
    while (($line = fgets($file)) !== false) {
        // Each line: firstName lastName email password
        $line = trim($line);
        $data = explode(" ", $line);

        if (count($data) == 4) {
            $firstName = $conn->real_escape_string($data[0]);
            $lastName  = $conn->real_escape_string($data[1]);
            $email     = $conn->real_escape_string($data[2]);
            $password  = $conn->real_escape_string($data[3]);

            $insert = "INSERT INTO tblUser 
                       (firstName, lastName, email, password) 
                       VALUES 
                       ('$firstName','$lastName','$email','$password')";

            if ($conn->query($insert) === TRUE) {
                echo "Inserted: $firstName $lastName <br>";
            } else {
                echo "Error inserting: " . $conn->error . "<br>";
            }
        }
    }
    fclose($file);
    echo "<br>All users loaded successfully!";
} else {
    echo "Error opening userData.txt";
}

// Recreate tblOrder
$createOrder = "CREATE TABLE IF NOT EXISTS tblOrder (
    orderID INT(11) AUTO_INCREMENT PRIMARY KEY,
    userID INT(11) NOT NULL,
    orderDate TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    totalAmount DECIMAL(10,2) NOT NULL,
    FOREIGN KEY (userID) REFERENCES tblUser(userID)
)";

if ($conn->query($createOrder) === TRUE) {
    echo "<br>tblOrder recreated successfully!";
} else {
    echo "<br>Error recreating tblOrder: " . $conn->error;
}

$conn->close();
?>