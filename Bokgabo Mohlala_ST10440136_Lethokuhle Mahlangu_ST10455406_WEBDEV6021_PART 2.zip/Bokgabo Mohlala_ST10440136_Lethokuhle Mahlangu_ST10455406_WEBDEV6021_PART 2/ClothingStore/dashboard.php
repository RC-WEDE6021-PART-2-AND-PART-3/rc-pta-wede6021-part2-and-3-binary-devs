<?php
session_start();
require_once 'DBConn.php';

// If not logged in, redirect to login page
if (!isset($_SESSION['userID'])) {
    header("Location: index.php");
    exit();
}

$userID    = $_SESSION['userID'];
$firstName = $_SESSION['firstName'];
$lastName  = $_SESSION['lastName'];
$email     = $_SESSION['email'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>ClothingStore - Dashboard</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f2f2f2;
            margin: 0;
            padding: 0;
        }
        .navbar {
            background: #333;
            color: white;
            padding: 15px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .navbar h1 {
            margin: 0;
            font-size: 22px;
        }
        .navbar a {
            color: white;
            text-decoration: none;
            padding: 8px 15px;
            background: #555;
            border-radius: 4px;
        }
        .navbar a:hover {
            background: #777;
        }
        .welcome-banner {
            background: #e0ffe0;
            color: #006600;
            padding: 15px 30px;
            font-size: 18px;
            font-weight: bold;
            border-bottom: 1px solid #b2d8b2;
        }
        .container {
            padding: 30px;
        }
        .card {
            background: white;
            padding: 25px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }
        .card h3 {
            margin-top: 0;
            color: #333;
            border-bottom: 2px solid #f2f2f2;
            padding-bottom: 10px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        table td {
            padding: 10px;
            border-bottom: 1px solid #f2f2f2;
            color: #555;
        }
        table td:first-child {
            font-weight: bold;
            color: #333;
            width: 150px;
        }
        .logout-btn {
            display: inline-block;
            padding: 10px 20px;
            background: #cc0000;
            color: white;
            text-decoration: none;
            border-radius: 4px;
            margin-top: 10px;
        }
        .logout-btn:hover {
            background: #aa0000;
        }
    </style>
</head>
<body>

<!-- Navbar -->
<div class="navbar">
    <h1>ClothingStore</h1>
    <a href="logout.php">Logout</a>
</div>

<!-- Welcome Banner -->
<div class="welcome-banner">
    User <?php echo htmlspecialchars($firstName . " " . $lastName); ?> is logged in.
</div>

<!-- Main Content -->
<div class="container">

    <!-- User Details Card -->
    <div class="card">
        <h3>Your Account Details</h3>
        <table>
            <tr>
                <td>First Name:</td>
                <td><?php echo htmlspecialchars($firstName); ?></td>
            </tr>
            <tr>
                <td>Last Name:</td>
                <td><?php echo htmlspecialchars($lastName); ?></td>
            </tr>
            <tr>
                <td>Email:</td>
                <td><?php echo htmlspecialchars($email); ?></td>
            </tr>
            <tr>
                <td>User ID:</td>
                <td><?php echo htmlspecialchars($userID); ?></td>
            </tr>
        </table>
    </div>

    <!-- Logout Card -->
    <div class="card">
        <h3>Session</h3>
        <p>You are currently logged in as 
           <strong><?php echo htmlspecialchars($firstName . " " . $lastName); ?></strong>.
        </p>
        <a href="logout.php" class="logout-btn">Logout</a>
    </div>

</div>

</body>
</html>