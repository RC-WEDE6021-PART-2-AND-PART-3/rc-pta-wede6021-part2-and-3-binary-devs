<?php
session_start();
require_once 'DBConn.php';

// If not logged in as admin, redirect to admin login
if (!isset($_SESSION['adminID'])) {
    header("Location: adminLogin.php");
    exit();
}

$adminFirst = $_SESSION['adminFirst'];
$adminLast  = $_SESSION['adminLast'];

$success = "";
$error   = "";

// =====================
// VERIFY USER
// =====================
if (isset($_GET['verify'])) {
    $verifyID = (int)$_GET['verify'];
    $conn->query("UPDATE tblUser SET isVerified = 1 WHERE userID = $verifyID");
    $success = "User verified successfully!";
}

// =====================
// DELETE USER
// =====================
if (isset($_GET['delete'])) {
    $deleteID = (int)$_GET['delete'];
    $conn->query("DELETE FROM tblUser WHERE userID = $deleteID");
    $success = "User deleted successfully!";
}

// =====================
// ADD USER
// =====================
if (isset($_POST['action']) && $_POST['action'] == 'add') {
    $firstName = $conn->real_escape_string(trim($_POST['firstName']));
    $lastName  = $conn->real_escape_string(trim($_POST['lastName']));
    $email     = $conn->real_escape_string(trim($_POST['email']));
    $password  = md5(trim($_POST['password']));

    // Check if email exists
    $check = $conn->query("SELECT * FROM tblUser WHERE email = '$email'");
    if ($check->num_rows > 0) {
        $error = "A user with that email already exists.";
    } else {
        $conn->query("INSERT INTO tblUser 
                     (firstName, lastName, email, password, isVerified) 
                     VALUES ('$firstName','$lastName','$email','$password', 1)");
        $success = "User added successfully!";
    }
}

// =====================
// UPDATE USER
// =====================
if (isset($_POST['action']) && $_POST['action'] == 'update') {
    $userID    = (int)$_POST['userID'];
    $firstName = $conn->real_escape_string(trim($_POST['firstName']));
    $lastName  = $conn->real_escape_string(trim($_POST['lastName']));
    $email     = $conn->real_escape_string(trim($_POST['email']));

    $conn->query("UPDATE tblUser SET 
                  firstName = '$firstName', 
                  lastName  = '$lastName', 
                  email     = '$email' 
                  WHERE userID = $userID");
    $success = "User updated successfully!";
}

// Fetch all users
$users = $conn->query("SELECT * FROM tblUser ORDER BY isVerified ASC, createdAt DESC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>ClothingStore - Admin Panel</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f2f2f2;
            margin: 0;
            padding: 0;
        }
        .navbar {
            background: #1a1a2e;
            color: white;
            padding: 15px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .navbar h1 {
            margin: 0;
            font-size: 22px;
        }
        .navbar a {
            color: white;
            text-decoration: none;
            padding: 8px 15px;
            background: #2a2a4e;
            border-radius: 4px;
        }
        .navbar a:hover {
            background: #3a3a6e;
        }
        .welcome-banner {
            background: #fff3cd;
            color: #856404;
            padding: 15px 30px;
            font-size: 16px;
            font-weight: bold;
            border-bottom: 1px solid #ffc107;
        }
        .container {
            padding: 30px;
        }
        .card {
            background: white;
            padding: 25px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }
        .card h3 {
            margin-top: 0;
            color: #1a1a2e;
            border-bottom: 2px solid #f2f2f2;
            padding-bottom: 10px;
        }
        .success {
            background: #e0ffe0;
            color: #006600;
            padding: 10px;
            border-radius: 4px;
            margin-bottom: 15px;
        }
        .error {
            background: #ffe0e0;
            color: #cc0000;
            padding: 10px;
            border-radius: 4px;
            margin-bottom: 15px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        table th {
            background: #1a1a2e;
            color: white;
            padding: 10px;
            text-align: left;
        }
        table td {
            padding: 10px;
            border-bottom: 1px solid #f2f2f2;
        }
        table tr:hover {
            background: #f9f9f9;
        }
        .badge-verified {
            background: #e0ffe0;
            color: #006600;
            padding: 3px 8px;
            border-radius: 10px;
            font-size: 12px;
        }
        .badge-pending {
            background: #fff3cd;
            color: #856404;
            padding: 3px 8px;
            border-radius: 10px;
            font-size: 12px;
        }
        .btn {
            padding: 5px 10px;
            border-radius: 4px;
            text-decoration: none;
            font-size: 13px;
            cursor: pointer;
            border: none;
            display: inline-block;
        }
        .btn-verify  { background: #28a745; color: white; }
        .btn-delete  { background: #cc0000; color: white; }
        .btn-edit    { background: #007bff; color: white; }
        .btn:hover   { opacity: 0.85; }

        .form-row {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
            margin-bottom: 10px;
        }
        .form-row input {
            flex: 1;
            padding: 8px;
            border: 1px solid #ccc;
            border-radius: 4px;
            min-width: 150px;
        }
        .form-row button {
            padding: 8px 20px;
            background: #1a1a2e;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        .form-row button:hover {
            background: #2a2a4e;
        }

        /* Edit modal */
        .modal {
            display: none;
            position: fixed;
            top: 0; left: 0;
            width: 100%; height: 100%;
            background: rgba(0,0,0,0.5);
            justify-content: center;
            align-items: center;
            z-index: 999;
        }
        .modal.active {
            display: flex;
        }
        .modal-box {
            background: white;
            padding: 30px;
            border-radius: 8px;
            width: 350px;
        }
        .modal-box h3 {
            margin-top: 0;
            color: #1a1a2e;
        }
        .modal-box input {
            width: 100%;
            padding: 8px;
            margin: 6px 0 12px 0;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }
        .modal-box button {
            width: 100%;
            padding: 10px;
            background: #1a1a2e;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            margin-bottom: 8px;
        }
        .modal-close {
            background: #cc0000 !important;
        }
    </style>
</head>
<body>

<!-- Navbar -->
<div class="navbar">
    <h1>ClothingStore - Admin Panel</h1>
    <a href="adminLogout.php">Logout</a>
</div>

<!-- Welcome Banner -->
<div class="welcome-banner">
    👤 Admin <?php echo htmlspecialchars($adminFirst . " " . $adminLast); ?> is logged in.
</div>

<div class="container">

    <?php if (!empty($success)): ?>
        <div class="success"><?php echo $success; ?></div>
    <?php endif; ?>
    <?php if (!empty($error)): ?>
        <div class="error"><?php echo $error; ?></div>
    <?php endif; ?>

    <!-- Add New User -->
    <div class="card">
        <h3>Add New Customer</h3>
        <form method="POST" action="adminPanel.php">
            <input type="hidden" name="action" value="add">
            <div class="form-row">
                <input type="text"     name="firstName" placeholder="First Name"  required>
                <input type="text"     name="lastName"  placeholder="Last Name"   required>
                <input type="email"    name="email"     placeholder="Email"       required>
                <input type="password" name="password"  placeholder="Password"    required>
                <button type="submit">Add Customer</button>
            </div>
        </form>
    </div>

    <!-- Users Table -->
    <div class="card">
        <h3>All Customers</h3>
        <table>
            <tr>
                <th>ID</th>
                <th>First Name</th>
                <th>Last Name</th>
                <th>Email</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>
            <?php while ($user = $users->fetch_assoc()): ?>
            <tr>
                <td><?php echo $user['userID']; ?></td>
                <td><?php echo htmlspecialchars($user['firstName']); ?></td>
                <td><?php echo htmlspecialchars($user['lastName']); ?></td>
                <td><?php echo htmlspecialchars($user['email']); ?></td>
                <td>
                    <?php if ($user['isVerified'] == 1): ?>
                        <span class="badge-verified">Verified</span>
                    <?php else: ?>
                        <span class="badge-pending">Pending</span>
                    <?php endif; ?>
                </td>
                <td>
                    <?php if ($user['isVerified'] == 0): ?>
                        <a href="adminPanel.php?verify=<?php echo $user['userID']; ?>" 
                           class="btn btn-verify">Verify</a>
                    <?php endif; ?>
                    <button class="btn btn-edit"
                        onclick="openEdit(
                            <?php echo $user['userID']; ?>,
                            '<?php echo htmlspecialchars($user['firstName']); ?>',
                            '<?php echo htmlspecialchars($user['lastName']); ?>',
                            '<?php echo htmlspecialchars($user['email']); ?>'
                        )">Edit</button>
                    <a href="adminPanel.php?delete=<?php echo $user['userID']; ?>"
                       class="btn btn-delete"
                       onclick="return confirm('Are you sure you want to delete this user?')">
                       Delete</a>
                </td>
            </tr>
            <?php endwhile; ?>
        </table>
    </div>

</div>

<!-- Edit Modal -->
<div class="modal" id="editModal">
    <div class="modal-box">
        <h3>Edit Customer</h3>
        <form method="POST" action="adminPanel.php">
            <input type="hidden" name="action"  value="update">
            <input type="hidden" name="userID"  id="editUserID">

            <label>First Name:</label>
            <input type="text"  name="firstName" id="editFirstName" required>

            <label>Last Name:</label>
            <input type="text"  name="lastName"  id="editLastName"  required>

            <label>Email:</label>
            <input type="email" name="email"     id="editEmail"     required>

            <button type="submit">Save Changes</button>
            <button type="button" class="modal-close"
                    onclick="closeEdit()">Cancel</button>
        </form>
    </div>
</div>

<script>
    function openEdit(id, firstName, lastName, email) {
        document.getElementById('editUserID').value    = id;
        document.getElementById('editFirstName').value = firstName;
        document.getElementById('editLastName').value  = lastName;
        document.getElementById('editEmail').value     = email;
        document.getElementById('editModal').classList.add('active');
    }

    function closeEdit() {
        document.getElementById('editModal').classList.remove('active');
    }
</script>

</body>
</html>