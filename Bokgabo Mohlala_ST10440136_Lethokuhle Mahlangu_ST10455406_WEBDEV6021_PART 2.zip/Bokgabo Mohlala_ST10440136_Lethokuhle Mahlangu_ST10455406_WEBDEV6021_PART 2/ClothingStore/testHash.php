<?php
// This will show us the md5 hash of common passwords
echo "md5 of 'c' = " . md5('c') . "<br>";
echo "md5 of 'password' = " . md5('password') . "<br>";
echo "md5 of '123456' = " . md5('123456') . "<br>";
echo "md5 of 'admin' = " . md5('admin') . "<br>";

echo "<br><hr><br>";

// Also show what is actually stored in the database
require_once 'DBConn.php';
$result = $conn->query("SELECT firstName, lastName, email, password FROM tblUser");
while ($row = $result->fetch_assoc()) {
    echo $row['firstName'] . " " . $row['lastName'] . 
         " | Email: " . $row['email'] . 
         " | Stored Hash: " . $row['password'] . "<br>";
}
?>