<?php
require_once 'DBConn.php';

// Drop all tables first (disable foreign key checks)
$conn->query("SET FOREIGN_KEY_CHECKS=0");

$conn->query("DROP TABLE IF EXISTS tblOrder");
echo "tblOrder dropped <br>";

$conn->query("DROP TABLE IF EXISTS tblUser");
echo "tblUser dropped <br>";

$conn->query("DROP TABLE IF EXISTS tblAdmin");
echo "tblAdmin dropped <br>";

$conn->query("DROP TABLE IF EXISTS tblClothes");
echo "tblClothes dropped <br>";

$conn->query("SET FOREIGN_KEY_CHECKS=1");
echo "<br>All tables dropped successfully! <br><br>";

// =====================
// CREATE tblUser
// =====================
$sql = "CREATE TABLE IF NOT EXISTS tblUser (
    userID INT(11) AUTO_INCREMENT PRIMARY KEY,
    firstName VARCHAR(50) NOT NULL,
    lastName VARCHAR(50) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    isVerified TINYINT(1) DEFAULT 0,
    createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)";
if ($conn->query($sql) === TRUE) {
    echo "tblUser created <br>";
} else {
    echo "Error creating tblUser: " . $conn->error . "<br>";
}

// =====================
// CREATE tblAdmin
// =====================
$sql = "CREATE TABLE IF NOT EXISTS tblAdmin (
    adminID INT(11) AUTO_INCREMENT PRIMARY KEY,
    firstName VARCHAR(50) NOT NULL,
    lastName VARCHAR(50) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL
)";
if ($conn->query($sql) === TRUE) {
    echo "tblAdmin created <br>";
} else {
    echo "Error creating tblAdmin: " . $conn->error . "<br>";
}

// =====================
// CREATE tblClothes
// =====================
$sql = "CREATE TABLE IF NOT EXISTS tblClothes (
    clothesID INT(11) AUTO_INCREMENT PRIMARY KEY,
    clothesName VARCHAR(100) NOT NULL,
    description TEXT,
    price DECIMAL(10,2) NOT NULL,
    stock INT(11) DEFAULT 0
)";
if ($conn->query($sql) === TRUE) {
    echo "tblClothes created <br>";
} else {
    echo "Error creating tblClothes: " . $conn->error . "<br>";
}

// =====================
// CREATE tblOrder
// =====================
$sql = "CREATE TABLE IF NOT EXISTS tblOrder (
    orderID INT(11) AUTO_INCREMENT PRIMARY KEY,
    userID INT(11) NOT NULL,
    orderDate TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    totalAmount DECIMAL(10,2) NOT NULL,
    FOREIGN KEY (userID) REFERENCES tblUser(userID)
)";
if ($conn->query($sql) === TRUE) {
    echo "tblOrder created <br>";
} else {
    echo "Error creating tblOrder: " . $conn->error . "<br>";
}

echo "<br>All tables created successfully! <br><br>";

// =====================
// LOAD tblUser DATA
// =====================
$file = fopen("userData.txt", "r");
if ($file) {
    while (($line = fgets($file)) !== false) {
        $line = trim($line);
        $data = explode(" ", $line);
        if (count($data) == 4) {
            $firstName = $conn->real_escape_string($data[0]);
            $lastName  = $conn->real_escape_string($data[1]);
            $email     = $conn->real_escape_string($data[2]);
            $password  = $conn->real_escape_string($data[3]);

            $conn->query("INSERT INTO tblUser 
                         (firstName, lastName, email, password) 
                         VALUES 
                         ('$firstName','$lastName','$email','$password')");
        }
    }
    fclose($file);
    echo "tblUser data loaded <br>";
}

// =====================
// LOAD tblAdmin DATA
// =====================
$file = fopen("adminData.txt", "r");
if ($file) {
    while (($line = fgets($file)) !== false) {
        $line = trim($line);
        $data = explode(" ", $line);
        if (count($data) == 4) {
            $firstName = $conn->real_escape_string($data[0]);
            $lastName  = $conn->real_escape_string($data[1]);
            $email     = $conn->real_escape_string($data[2]);
            $password  = $conn->real_escape_string($data[3]);
            $conn->query("INSERT INTO tblAdmin 
                         (firstName, lastName, email, password) 
                         VALUES 
                         ('$firstName','$lastName','$email','$password')");
        }
    }
    fclose($file);
    echo "tblAdmin data loaded <br>";
}

// =====================
// LOAD tblClothes DATA
// =====================
$file = fopen("clothesData.txt", "r");
if ($file) {
    while (($line = fgets($file)) !== false) {
        $line = trim($line);
        $data = explode(" ", $line);
        if (count($data) == 4) {
            $name  = $conn->real_escape_string(str_replace('-', ' ', $data[0]));
            $desc  = $conn->real_escape_string(str_replace('-', ' ', $data[1]));
            $price = $data[2];
            $stock = $data[3];
            $conn->query("INSERT INTO tblClothes 
                         (clothesName, description, price, stock) 
                         VALUES ('$name','$desc',$price,$stock)");
        }
    }
    fclose($file);
    echo "tblClothes data loaded <br>";
}

// =====================
// LOAD tblOrder DATA
// =====================
$file = fopen("orderData.txt", "r");
if ($file) {
    while (($line = fgets($file)) !== false) {
        $line = trim($line);
        $data = explode(" ", $line);
        if (count($data) == 3) {
            $userID      = (int)$data[0];
            $orderDate   = $conn->real_escape_string($data[1]);
            $totalAmount = $data[2];
            $conn->query("INSERT INTO tblOrder 
                         (userID, orderDate, totalAmount) 
                         VALUES ($userID,'$orderDate',$totalAmount)");
        }
    }
    fclose($file);
    echo "tblOrder data loaded <br>";
}

echo "<br><strong>All done! ClothingStore database fully loaded!</strong>";

$conn->close();
?>