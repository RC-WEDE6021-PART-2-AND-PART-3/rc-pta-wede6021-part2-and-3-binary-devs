<?php
session_start();
require_once 'DBConn.php';

$error = "";
$success = "";

// Sticky form variables
$firstName = "";
$lastName = "";
$email = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $firstName = $conn->real_escape_string(trim($_POST['firstName']));
    $lastName  = $conn->real_escape_string(trim($_POST['lastName']));
    $email     = $conn->real_escape_string(trim($_POST['email']));
    $password  = trim($_POST['password']);
    $confirm   = trim($_POST['confirm']);

    // Validation
    if (empty($firstName) || empty($lastName) || empty($email) || empty($password) || empty($confirm)) {
        $error = "All fields are required.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Please enter a valid email address.";
    } elseif ($password !== $confirm) {
        $error = "Passwords do not match.";
    } else {
        // Check if email already exists
        $check = "SELECT * FROM tblUser WHERE email = '$email'";
        $result = $conn->query($check);

        if ($result->num_rows > 0) {
            $error = "An account with that email already exists.";
        } else {
            // Hash the password using md5
            $hashedPassword = md5($password);

            // Insert new user (isVerified = 0 by default)
            $insert = "INSERT INTO tblUser 
                       (firstName, lastName, email, password, isVerified) 
                       VALUES 
                       ('$firstName','$lastName','$email','$hashedPassword', 0)";

            if ($conn->query($insert) === TRUE) {
                $success = "Registration successful! Please wait for an 
                            administrator to verify your account before logging in.";
                // Clear form fields on success
                $firstName = "";
                $lastName  = "";
                $email     = "";
            } else {
                $error = "Registration failed: " . $conn->error;
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>ClothingStore - Register</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f2f2f2;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .register-box {
            background: white;
            padding: 40px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            width: 350px;
        }
        h2 {
            text-align: center;
            color: #333;
            margin-bottom: 20px;
        }
        .error {
            background: #ffe0e0;
            color: #cc0000;
            padding: 10px;
            border-radius: 4px;
            margin-bottom: 15px;
            text-align: center;
        }
        .success {
            background: #e0ffe0;
            color: #006600;
            padding: 10px;
            border-radius: 4px;
            margin-bottom: 15px;
            text-align: center;
        }
        label {
            font-weight: bold;
            color: #333;
        }
        input[type="text"],
        input[type="email"],
        input[type="password"] {
            width: 100%;
            padding: 10px;
            margin: 8px 0 16px 0;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }
        input[type="submit"] {
            width: 100%;
            padding: 10px;
            background: #333;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
        }
        input[type="submit"]:hover {
            background: #555;
        }
        .links {
            text-align: center;
            margin-top: 15px;
        }
        .links a {
            color: #333;
            text-decoration: none;
        }
        .links a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>

<div class="register-box">
    <h2>Create Account</h2>

    <?php if (!empty($error)): ?>
        <div class="error"><?php echo $error; ?></div>
    <?php endif; ?>

    <?php if (!empty($success)): ?>
        <div class="success"><?php echo $success; ?></div>
    <?php endif; ?>

    <form method="POST" action="register.php">
        <label>First Name:</label>
        <input type="text" name="firstName"
               value="<?php echo htmlspecialchars($firstName); ?>"
               required>

        <label>Last Name:</label>
        <input type="text" name="lastName"
               value="<?php echo htmlspecialchars($lastName); ?>"
               required>

        <label>Email Address:</label>
        <input type="email" name="email"
               value="<?php echo htmlspecialchars($email); ?>"
               required>

        <label>Password:</label>
        <input type="password" name="password" required>

        <label>Confirm Password:</label>
        <input type="password" name="confirm" required>

        <input type="submit" value="Register">
    </form>

    <div class="links">
        <a href="index.php">Already have an account? Login</a>
    </div>
</div>

</body>
</html>